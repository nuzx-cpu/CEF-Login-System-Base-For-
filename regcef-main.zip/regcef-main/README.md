# regcef

Video: https://www.youtube.com/watch?v=ldVtdRksb6E

Замените путь к файлу index.html в строке 365

```C++
cef_create_browser(playerid, LOGIN_BROWSER_ID, "C://Users//youj33n//Desktop//CefRegistration//siteLogin//index.html", false, true);
```

![preview](http://images.vfl.ru/ii/1645108409/2121d1f5/38084865.png)



